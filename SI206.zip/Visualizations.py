import sqlite3
import json
import matplotlib
import matplotlib.pyplot as plt
import math
import csv
import numpy as np
import statistics

# Draw BPM / Time graph

def BPM_Graph(database):

    conn = sqlite3.connect(database) 
    cur = conn.cursor()

    avg_dict = {}
    cur.execute('SELECT * from SongStats INNER JOIN Top_Songs on Top_Songs.ID = SongStats.ID')
    rows = cur.fetchall()
    xlist = []
    ylist = []

    
    for row in rows:

        if row[8] in avg_dict:
            avg_dict[row[8]] += float(row[3])
        else:
            avg_dict[row[8]] = float(row[3])

      
    with open('Visualizations.csv', 'a') as f:
        f.write('Year, Average BPM of Hit Songs\n')
        years = avg_dict.keys()

        for year in years:
            xlist.append(year)
            ylist.append(int(avg_dict[year]))
            f.write("{},{}\n".format(year, avg_dict[year]))
            
        f.write('\n')

    
    plt.figure(1)
    plt.plot(xlist,ylist, 'p-')
    plt.xlabel('Year')
    plt.ylabel('Average BPM for Hit Songs')
    plt.title('Beats per Minute (BPM) for Hit Songs Over Time')
    plt.text(1990, 1300, "Correlation Coefficient: " + str(round(np.corrcoef(xlist,ylist)[1,0],2)), 
    style = 'italic', bbox = {'facecolor': 'white'})
    #plt.show()
    #plt.savefig('BPM Over Time') 

# Draw Danceability / Time graph

def Dance_Graph(database):

    conn = sqlite3.connect(database) 
    cur = conn.cursor()

    avg_dict = {}
    cur.execute('SELECT * from SongStats INNER JOIN Top_Songs on Top_Songs.ID = SongStats.ID')
    rows = cur.fetchall()
    xlist = []
    ylist = []

    
    for row in rows:

        if row[8] in avg_dict:
            avg_dict[row[8]] += row[4]
        else:
            avg_dict[row[8]] = row[4]
 

    with open('Visualizations.csv', 'a') as f:
        f.write('Year, Average Danceability of Hit Songs\n')
        years = avg_dict.keys()

        for key in avg_dict:
            avg_dict[key] = (avg_dict[key] / 10)
            xlist.append(key)
            ylist.append(avg_dict[key])
            f.write("{},{}\n".format(key, avg_dict[key]))
        
        f.write('\n')

    plt.figure(2)
    plt.plot(xlist,ylist, 'p-')
    plt.xlabel('Year')
    plt.ylabel('Average Danceability for Hit Songs')
    plt.title('Danceability for Hit Songs Over Time')
    plt.text(1990, .725, "Correlation Coefficient: " + str(round(np.corrcoef(xlist,ylist)[1,0],2)), 
    style = 'italic', bbox = {'facecolor': 'white'})
    plt.draw()

# Draw Average Sentiment / Time Graph

def Sentiment_Graph(database):

    conn = sqlite3.connect(database) 
    cur = conn.cursor()

    avg_sent = {}
    cur.execute('SELECT Top_Songs.ID, Year, Negative, Neutral, Positive FROM Top_Songs INNER JOIN Lyrics_Sentiment on Top_Songs.ID = Lyrics_Sentiment.ID')

    xlist = []
    ylist = []
    header_row = ["Year", "Average Sentiment of Hit Songs"]
    for row in cur:
        year = row[1]
        sentiment = row[2]*(-1) + row[3]*(0) + row[4]*(1)
        
        if year in avg_sent:
            avg_sent[year] += sentiment / 10
        else:
            avg_sent[year] = sentiment / 10
    
    with open("Visualizations.csv", 'a', encoding = 'utf-8', newline = '') as writeFile:
        writer = csv.writer(writeFile)
        writer.writerow(header_row)

        for year in avg_sent:
            xlist.append(year)
            ylist.append(avg_sent[year])
            csv_row = [year, avg_sent[year]]
            writer.writerow(csv_row)

        writeFile.write('\n')
    
    plt.figure(3)
    plt.plot(xlist,ylist, marker = 'o')
    plt.xlabel("Year")
    plt.ylabel("Average Sentiment (1 = most positive, -1 = most negative)")
    plt.title("Average Sentiment of Popular Songs Over Time")
    plt.text(2006, 0.5, "Correlation Coefficient: " + str(round(np.corrcoef(xlist,ylist)[1,0],2)), 
    style = 'italic', bbox = {'facecolor': 'white'})

# Draw average lyric count over time

def LyricLength_Graph(database):

    conn = sqlite3.connect(database) 
    cur = conn.cursor()

    data_dict = {}
    cur.execute('SELECT Top_Songs.ID,  Lyrics, Year from Lyrics_Sentiment inner join Top_Songs on Lyrics_Sentiment.ID = Top_Songs.ID')

    for row in cur:
        word_count = 0
        words = row[1].split()
        year = row[2]

        for word in words:
            word_count += 1

        if year not in data_dict:
            data_dict[year] = []
        
        data_dict[year].append(word_count)

    years = data_dict.keys()
    year_avg = []

    with open('Visualizations.csv','a') as f:
        f.write('Year, Average Lyric Length of Hit Songs\n')

        dict_for_CSV = {}
        for year in years:
            avg = statistics.mean(data_dict[year])
            year_avg.append(avg)
            if year not in dict_for_CSV:
                dict_for_CSV[year] = 0
            dict_for_CSV[year] = avg

        for year in years:
            f.write('{},{}\n'.format(year, int(dict_for_CSV[year]))) 
        
        f.write('\n')

    xlist = []
    ylist = year_avg

    for year in years:
        xlist.append(year)

    plt.figure(4)
    plt.plot(xlist, ylist, marker = 'o')
    plt.xlabel("Year")
    plt.ylabel("Average Number of Words")
    plt.title("Average Number of Words in Top Songs (1990-2019)")
    plt.text(2006, 950, "Correlation Coefficient: " + str(round(np.corrcoef(xlist,ylist)[1,0],2)), 
    style = 'italic', bbox = {'facecolor': 'white'})

# Draw average YT Views over time

def YTviews_Graph(database):

    conn = sqlite3.connect(database) 
    cur = conn.cursor()

    avg_dict = {}
    cur.execute('SELECT Top_Songs.ID, Views, Year FROM Top_Songs INNER JOIN YTviews on Top_Songs.ID = YTviews.ID')

    xlist = []
    ylist = []
    
    for row in cur:
        #print(row)
        year = row[2]
        views = int(row[1])

        if year in avg_dict:
            avg_dict[year] += views / 10
        else:
            avg_dict[year] = views / 10
        
    header_row = ['Year', "Average YT Views of Hit Songs"]

    with open('Visualizations.csv', 'a', encoding = 'utf-8', newline = '') as writefile:
        writer = csv.writer(writefile)
        writer.writerow(header_row)
        for key in avg_dict:
            xlist.append(key)
            ylist.append(int(avg_dict[key]))
            csv_row = [key, avg_dict[key]]
            writer.writerow(csv_row)

    plt.figure(5)
    plt.scatter(xlist, ylist)
    plt.plot(xlist,ylist, 'p-')
    plt.xlabel('Years')
    plt.ylabel('Views Over Time (In Billions)')
    plt.title('YouTube Views for Hit Songs Over Time')
    plt.text(1990, 500000000, "Correlation Coefficient: " + str(round(np.corrcoef(xlist,ylist)[1,0],2)), 
    style = 'italic', bbox = {'facecolor': 'white'})

db = 'SIfinal.sqlite'
BPM_Graph(db)
Dance_Graph(db)
Sentiment_Graph(db)
LyricLength_Graph(db)
YTviews_Graph(db)
plt.show()