#youtube.py 
import os
import googleapiclient.discovery
import requests
import sqlite3
import re

###
### Change this to 20 calls!
###

yt_pw = "AIzaSyApy89cDHnmb3Hhl2x00DVmAH5EvQzFER0"

conn = sqlite3.connect('SIfinal.sqlite')
cur = conn.cursor()
cur.execute('CREATE TABLE IF NOT EXISTS YTviews (ID INTEGER, Views INTEGER)')

os.environ["OAUTH_INSECURE_TRANSPORT"] = "1"
api_service_name = 'youtube'
api_version = 'v3'

cur.execute('SELECT ID, Song, Artist FROM Top_Songs')
sql = "INSERT INTO YTviews (ID, Views) Values(?, ?)"

rows = cur.fetchall()

youtube = googleapiclient.discovery.build(api_service_name,api_version,developerKey = yt_pw)

# Get top N youtube videos and their respective links
numResults = 3

for row in rows:

    try:
        ID = row[0]
        song = row[1].lower()
        artist = row[2].lower()
        print(row)

        song = song.lower()
        artist = artist.lower()

        escape = ["featuring", "(featuring", "&", "x"]
        temp = []
        artist_list = artist.split(' ')
        for word in artist_list:
            if word in escape:
                break
            temp.append(word)
        artist = " ".join(temp)
        #print(artist)

        song_temp = []
        song = re.sub('\/.+','',song)
        song_list = song.split(' ')
        print(song_list)
        for word in song_list:
            if "(from" in word:
                break
            song_temp.append(word)
        song = " ".join(song_temp)
        print(song)



        request = youtube.search().list(part = "snippet", maxResults = numResults, q = artist + " " + song)
        response = request.execute()

        max_views = 0
        id_str = ""

        for search in range(numResults):
            id_str += response['items'][search]['id']['videoId'] + ", "

        id_str = id_str.rstrip(", ")


        # Check which video has the maximum number of views and set that equal to max_views
        new_request = youtube.videos().list(part = 'statistics', id = id_str)
        new_response = new_request.execute()

        for search in range(numResults):
            views = int(new_response['items'][search]['statistics']['viewCount'])
            if views > max_views:
                max_views = views

        val = (ID, max_views)
        cur.execute(sql, val)
    except:
        ID = row[0]
        max_views = 0

        val = (ID, max_views)
        cur.execute(sql, val)

conn.commit()
    


