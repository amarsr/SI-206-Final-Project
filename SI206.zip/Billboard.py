import billboard
import requests
import json
import sqlite3
import re

def get_top_10(date, chart_type = 'Hot-100'):

    conn = sqlite3.connect('SIfinal.sqlite')
    cur = conn.cursor()

    cur.execute('CREATE TABLE if Not Exists Top_Songs (ID INTEGER, Song TEXT, Artist TEXT, Year TIMESTAMP)')
    sql = 'INSERT INTO Top_Songs (ID, Song, Artist, Year) Values(?,?,?,?)'
    
    chart = billboard.ChartData(chart_type, date,  timeout = 25)
    #take top ten artists and append to list
    list_top10 = []
    for i in range(10):
        list_top10.append(str(chart[i]))

    id = 100
    for song in list_top10:
        id += 1
        split = song.split(' by ')
        Song = split[0].strip('\"\'')
        Artist = split[1].strip('\"\'')
        year = date[0:4]

        val = (id, Song, Artist, year)
        cur.execute(sql, val)
    
  
    conn.commit()
    
################ Input in 'YYYY-MM-DD' format to get top 10 songs of that week ########################
  
get_top_10('2019-01-01')