import sys
import spotipy
import spotipy.util as util
from spotipy.oauth2 import SpotifyClientCredentials
import pprint
import json
import time
import sqlite3
import re
import API_Keys



#token = util.prompt_for_user_token(username,scope,client_id='f634757dd0cc4776a37b8d44c99d025b',client_secret='26547c1cde704ebf8fdc326b575a4429',redirect_uri='https://www.si.umich.edu/')

client_id = API_Keys.client_id
client_secret = API_Keys.client_secret

client_credentials_manager = SpotifyClientCredentials(client_id=client_id, client_secret=client_secret)
sp = spotipy.Spotify(client_credentials_manager=client_credentials_manager)
sp.trace=True


def get_data(song, artist):

    query = song + ' ' + artist

    results = sp.search(q=query, type='track', limit=5, market=None)

    #results = sp.search(q='Another Day In Paradise Phil Collins', type='track', limit=5, market=None)


    for result in results['tracks']['items']:
        tids = result['id']
        return tids

def get_Dance(tids):

    features = sp.audio_features(tids)
    Danceability = features[0].get('danceability')
    return Danceability

def get_BPM(tids):

    features = sp.audio_features(tids)
    BPM = features[0].get('tempo')
    return BPM
    
    
if __name__ == "__main__":
    conn = sqlite3.connect('SIfinal.sqlite')
    cur = conn.cursor()

    ID_Count_Start = 1
    ID_Count_End = ID_Count_Start + 20

    cur.execute('SELECT ID, artist, song FROM Top_Songs WHERE ID>={} and ID<={}'.format(ID_Count_Start, ID_Count_End))
    rows = cur.fetchall()

    cur.execute('CREATE TABLE if Not Exists SongStats (ID INTEGER, Song TEXT, Artist TEXT, BPM INTEGER, Danceability INTEGER)')
    sql = 'INSERT INTO SongStats (ID, Song, Artist, BPM, Danceability) Values(?,?,?,?,?)'


    for row in rows:
        ID = row[0]
        Artist = row[1]
        Song = row[2]
        
        Song = Song.lower()
        Artist = Artist.lower()
        escape = ["featuring", "(featuring", "&", " x "]
        temp = []
        artist_list = Artist.split(' ')
        for word in artist_list:
            if word in escape:
                break
            temp.append(word)
        Artist = " ".join(temp)

        song_temp = []
        Song = re.sub('\/.+','',Song)
        song_list = Song.split(' ')
        for word in song_list:
            if "(from" in word:
                break
            song_temp.append(word)
        Song = " ".join(song_temp)

        new_id = get_data(Song, Artist)

        dance = get_Dance(new_id)
        bpm = get_BPM(new_id)
        val = (ID, row[2], row[1], bpm, dance)
        cur.execute(sql, val)
    
    conn.commit()






